﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HesapMakinesiFurkanAkyürek
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int sayi1 = 0, sayi2 = 0;
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void toplama_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text;
            bilgi.islem = 1;
            textBox1.Clear();
            bilgi.ifade = "+";
        }

        private void cikartma_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text;
            bilgi.islem = 2;
            textBox1.Clear();
            bilgi.ifade = "-";
        }

        private void carpim_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text;
            bilgi.islem = 3;
            textBox1.Clear();
            bilgi.ifade = "*";
        }

        private void bolum_Click(object sender, EventArgs e)
        {
            textBox2.Text = textBox1.Text;
            bilgi.islem = 4;
            textBox1.Clear();
            bilgi.ifade = "/";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn0_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            textBox1.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";
        }

        private void btnSonuc_Click(object sender, EventArgs e)
        {
            int sonuc = 0;
            if (bilgi.islem == 0)
            {
                MessageBox.Show("Bir işlem seçmelisiniz!",
                "Hata!!!");
            }
            else if (bilgi.islem == 1)
            {
                sonuc = Convert.ToInt32(textBox2.Text) + Convert.ToInt32(textBox1.Text);
            }
            else if (bilgi.islem == 2)
            {
                sonuc = Convert.ToInt32(textBox2.Text) - Convert.ToInt32(textBox1.Text);
            }
            else if (bilgi.islem == 3)
            {
                sonuc = Convert.ToInt32(textBox2.Text) * Convert.ToInt32(textBox1.Text);
            }

            else if (bilgi.islem == 4)
            {
                try
                {
                    sonuc = Convert.ToInt32(textBox2.Text) / Convert.ToInt32(textBox1.Text);
                }
                catch (DivideByZeroException)
                {
                    MessageBox.Show("SIFIRA BÖLEMEZSİN!!!!" +
                        "DivideByZeroException Hatası");
                }
                catch (FormatException)
                { MessageBox.Show("BİR ŞEY GİRSENE"); }
            }



            listBox1.Items.Add(textBox2.Text + bilgi.ifade + textBox1.Text + " = " + sonuc.ToString());

            textBox1.Clear();
            textBox2.Clear();
        }
    }
}
