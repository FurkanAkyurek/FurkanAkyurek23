﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HesapMakinesiFurkanAkyürek
{
    class bilgi
    {
        public static int islem = 0;
        public static string ifade = "Hata!";
    }
}
